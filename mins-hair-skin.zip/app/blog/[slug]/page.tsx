import Breadcrumb from "@/components/breadcrumb"
import BlogPostContent from "@/components/blog/blog-post-content"
import AboutSidebar from "@/components/about/about-sidebar"

interface BlogPostPageProps {
  params: {
    slug: string
  }
}

export default function BlogPostPage({ params }: BlogPostPageProps) {
  // In a real app, fetch the blog post data based on the slug
  const post = {
    title: "Bí mật đằng sau những cánh cửa luôn chật ních người của Salon tóc nam Min Shair Skin",
    content: `Đó có thể là 5 cửa hàng rộng khắp toàn quốc song 5 khi người ta không biết giải cánh hàng loạt xe máy, ô tô đậu đầy dài trước các cửa tiệm salon cắt tóc nam Min Shair Skin. Chưa kể mới đây là tất đến nhờ cắt tóc xịn kiểu tăng đột biến, trung bình một cửa hàng phải nhận tiếp đô hàng nghìn lượt khách mỗi ngày, ai cũng háo hức để có được kiểu tóc đẹp trai siêu hot chỉ 100K. Đâu là bí mật sau thực sự hút khủng tưởng đó?`,
    sections: [
      {
        title: "Trải nghiệm thư giãn cực mê",
        content:
          "Thay vì chỉ gọi đầu, cắt tóc là xong như các tiệm tóc nam thông thường, tại Min Shair Skin anh em sẽ được tận hưởng quy trình chăm sóc đa công nghệ cao như rửa spa. Đội ngũ Skinner khéo léo, massage khắp khuôn mặt, trên huyệt thư giãn mang đến cho bạn cảm giác thư thái, trút hết mọi mệt mỏi để bước ra khỏi salon với phong thái tự tin hơn bao giờ hết.",
      },
      {
        title: "Mức giá hời cho một combo chăm sóc toàn diện",
        content:
          "Một trong những điểm điểm làm nên tên tuổi Min Shair Skin khiến khách hàng thay đổi thói quen cắt tóc ở tiệm đầu ngõ chính là gói dịch vụ Shine combo 100K. Khái niệm combo 7 bước đã qua quên thuộc với những vị khách ruột của Min Shair Skin, trải nghiệm tất cả các bước: Rửa mặt – Chăm sóc da mặt công nghệ cao – Gội đầu massage – Tư vấn kiểu tóc phù hợp theo khuôn mặt – Cắt tạo kiểu bởi những Stylist hàng đầu – Cao mặt ém đi, gọt xả kỹ càng – Vuốt sáp tạo kiểu. Trọn gói cực kính tế chỉ 100K không làm đau ví tiền mà và mới mẻ tóc đẹp, sau đó bạn sẽ đẹp trai hoàn hảo!",
      },
      {
        title: "Đội ngũ stylist chuyên nghiệp – Hiểu bạn hơn cả chính bạn",
        content:
          "Mỗi stylist ở Min Shair Skin là sở hữu những cá tính, thế mạnh về một kiểu tóc khác nhau, nhưng đều chung sự tận tâm, khéo léo, mong muốn đem đến cho phái mạnh những kiểu tóc đẹp trai, dẫn đầu xu hướng để tự tin bứt phá trong sự nghiệp. Chỉ cần bạn đưa ra yêu cầu, stylist sẽ tư vấn kiểu tóc phù hợp dựa trên khuôn mặt, tính trạng sức khỏe của tóc cũng như phong cách mà bạn hướng tới.",
      },
      {
        title: "Dịch vụ chăm sóc nhiệt tình – Đặt lịch qua app tiện lợi",
        content:
          "Tại Min Shair Skin, khách hàng được đội ngũ nhân viên trẻ trung thực quan tâm đến từng chi tiết nhỏ như đầu xe, sạc xe điện, wifi, nước uống miễn phí lạnh mát,... Đây là quy chuẩn về con người mà Min Shair Skin luôn hướng tới để nâng tầm trải nghiệm của anh em. Đặc biệt đủ luôn trong tình trạng chật rích nhưng mọi khách hàng đều không cần chờ đợi lâu cắt tóc vì đã được đặt lịch từ trước thông qua ứng dụng cài đặt sẵn trên điện thoại. Quả là điểm cộng to lớn cho những khách hàng bận rộn.",
      },
    ],
    relatedPosts: [
      {
        title: "Là đàn ông, đừng bỏ lỡ 3 kiểu tóc nam Hot Trend nhất 2020 này",
        slug: "3-kieu-toc-nam-hot-trend",
      },
      {
        title: "Side Swept Nam: Làm thế nào để duy trì vẻ lãng tử dài lâu?",
        slug: "side-swept-nam",
      },
      {
        title: "Hướng dẫn vuốt tóc layer tại nhà mà vẫn đẹp hoàn hảo",
        slug: "huong-dan-vuot-toc-layer",
      },
      {
        title: 'Bí quyết chăm sóc tóc Sport để anh em luôn "chuẩn men"',
        slug: "cham-soc-toc-sport",
      },
    ],
  }

  return (
    <main className="bg-white py-8">
      <div className="container mx-auto">
        <Breadcrumb
          items={[
            { label: "Trang chủ", href: "/" },
            { label: "Blog", href: "/blog" },
            { label: post.title, href: `/blog/${params.slug}` },
          ]}
        />

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 mt-8">
          <div className="lg:col-span-3">
            <BlogPostContent post={post} />
          </div>
          <div className="lg:col-span-1">
            <AboutSidebar />
          </div>
        </div>
      </div>
    </main>
  )
}

