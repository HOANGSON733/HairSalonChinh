"use client"

import { useState } from "react"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const products = [
  {
    id: 1,
    name: "Sáp Reuzel Red Pomade Phong Cách Cổ Điển",
    price: "228,000đ",
    image: "/placeholder.svg",
    category: "tao-kieu-toc",
  },
  {
    id: 2,
    name: "Sáp Reuzel Clay Matte Pomade Không Bóng",
    price: "273,000đ",
    image: "/placeholder.svg",
    category: "tao-kieu-toc",
  },
  {
    id: 3,
    name: "Sáp Reuzel Fiber Pomade Mềm Dẻo",
    price: "271,000đ",
    image: "/placeholder.svg",
    category: "tao-kieu-toc",
  },
  {
    id: 4,
    name: "Sáp Reuzel Blue Pomade Độ Bóng Cao",
    price: "243,000đ",
    image: "/placeholder.svg",
    category: "tao-kieu-toc",
  },
  {
    id: 5,
    name: "Sáp Reuzel Green Pomade Giữ Nếp Vừa",
    price: "228,000đ",
    image: "/placeholder.svg",
    category: "tao-kieu-toc",
  },
  {
    id: 6,
    name: "Combo Máy Sấy và Tinh Dầu Fan-om Vip",
    price: "699,000đ",
    originalPrice: "739,000đ",
    image: "/placeholder.svg",
    category: "cham-soc-toc",
    isNew: true,
  },
]

interface ProductGridProps {
  category: string
}

export default function ProductGrid({ category }: ProductGridProps) {
  const [sortBy, setSortBy] = useState("newest")

  const filteredProducts = products.filter((product) => category === "all" || product.category === category)

  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case "price-asc":
        return Number.parseInt(a.price.replace(/\D/g, "")) - Number.parseInt(b.price.replace(/\D/g, ""))
      case "price-desc":
        return Number.parseInt(b.price.replace(/\D/g, "")) - Number.parseInt(a.price.replace(/\D/g, ""))
      case "name-asc":
        return a.name.localeCompare(b.name)
      case "name-desc":
        return b.name.localeCompare(a.name)
      default:
        return 0
    }
  })

  return (
    <div>
      <div className="flex justify-end mb-6">
        <Select value={sortBy} onValueChange={setSortBy}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Sắp xếp theo" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="newest">Mới nhất</SelectItem>
            <SelectItem value="price-asc">Giá tăng dần</SelectItem>
            <SelectItem value="price-desc">Giá giảm dần</SelectItem>
            <SelectItem value="name-asc">Tên A-Z</SelectItem>
            <SelectItem value="name-desc">Tên Z-A</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {sortedProducts.map((product) => (
          <Card key={product.id} className="group">
            <CardContent className="p-4">
              <div className="relative aspect-square mb-4">
                <Image
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  fill
                  className="object-contain group-hover:scale-105 transition-transform duration-300"
                />
                {product.isNew && (
                  <div className="absolute top-2 right-2 bg-red-500 text-white px-2 py-1 text-xs font-bold rounded">
                    NEW
                  </div>
                )}
              </div>
              <h3 className="font-medium text-center mb-2 group-hover:text-[#FF9900] transition-colors">
                {product.name}
              </h3>
              <div className="flex flex-col items-center gap-1">
                <span className="font-bold text-red-600">{product.price}</span>
                {product.originalPrice && (
                  <span className="text-sm text-gray-500 line-through">{product.originalPrice}</span>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

