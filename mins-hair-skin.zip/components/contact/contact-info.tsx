import { MapPin, Phone, Mail, Facebook, Youtube, Instagram } from "lucide-react"

export default function ContactInfo() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-xl font-bold mb-6">THÔNG TIN LIÊN HỆ</h2>
        <div className="space-y-4">
          <div className="flex items-start gap-3">
            <MapPin className="w-5 h-5 text-[#FF9900] flex-shrink-0 mt-1" />
            <div>
              <p className="font-medium">Trụ sở chính:</p>
              <p className="text-gray-600">82 Trần Đại Nghĩa, P. Đồng Tâm, Q. Hai Bà Trưng, Hà Nội</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Phone className="w-5 h-5 text-[#FF9900]" />
            <div>
              <p className="font-medium">Hotline:</p>
              <p className="text-gray-600">0961.665.266</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Mail className="w-5 h-5 text-[#FF9900]" />
            <div>
              <p className="font-medium">Email:</p>
              <p className="text-gray-600">info@minshairskin.com</p>
            </div>
          </div>
        </div>
      </div>

      <div>
        <h2 className="text-xl font-bold mb-6">THEO DÕI CHÚNG TÔI</h2>
        <div className="flex gap-4">
          <a
            href="#"
            className="w-10 h-10 bg-blue-600 text-white rounded-full flex items-center justify-center hover:bg-blue-700 transition-colors"
          >
            <Facebook className="w-5 h-5" />
          </a>
          <a
            href="#"
            className="w-10 h-10 bg-red-600 text-white rounded-full flex items-center justify-center hover:bg-red-700 transition-colors"
          >
            <Youtube className="w-5 h-5" />
          </a>
          <a
            href="#"
            className="w-10 h-10 bg-pink-600 text-white rounded-full flex items-center justify-center hover:bg-pink-700 transition-colors"
          >
            <Instagram className="w-5 h-5" />
          </a>
        </div>
      </div>

      <div>
        <h2 className="text-xl font-bold mb-6">BẢN ĐỒ</h2>
        <div className="aspect-video rounded-lg overflow-hidden">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3724.7295561235523!2d105.84772731476292!3d21.007025386010126!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135ac428c3336e5%3A0x3c1f3a8f6d1c1e6c!2zODIgVHLhuqduIMSQ4bqhaSBOZ2jEqWEsIMSQ4buTbmcgVMOibSwgSGFpIELDoCBUcsawbmcsIEjDoCBO4buZaSwgVmnhu4d0IE5hbQ!5e0!3m2!1svi!2s!4v1623456789012!5m2!1svi!2s"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
          />
        </div>
      </div>
    </div>
  )
}

