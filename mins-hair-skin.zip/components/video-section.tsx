import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"

export default function VideoSection() {
  const videos = [
    {
      title: '"DARE TO SHINE" - BST 4 KIỂU TÓC NAM ĐẸP',
      thumbnail: "/placeholder.svg",
    },
    {
      title: 'Bí Troll Cắt Tóc, Vĩnh Và Vũ Được "Biến Hình" Thành Hot Boy',
      thumbnail: "/placeholder.svg",
    },
    {
      title: "Laydy Cùng Thành Viên Mới Đi Cắt Tóc Đẹp Trai",
      thumbnail: "/placeholder.svg",
    },
    {
      title: "Sẽ NTN Khi Lou Hoàng Để Tóc Mullet?",
      thumbnail: "/placeholder.svg",
    },
  ]

  return (
    <section className="py-16 bg-black">
      <div className="container mx-auto">
        <h2 className="text-3xl font-bold text-white mb-8">MIN SHAIR SKIN TV</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {videos.map((video, index) => (
            <Card key={index} className="bg-zinc-800">
              <CardContent className="p-0">
                <div className="relative aspect-video">
                  <Image
                    src={video.thumbnail || "/placeholder.svg"}
                    alt={video.title}
                    fill
                    className="object-cover rounded-t"
                  />
                  <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                    <div className="w-12 h-12 rounded-full bg-white/80 flex items-center justify-center">
                      <div className="w-0 h-0 border-t-8 border-b-8 border-l-12 border-transparent border-l-black translate-x-1" />
                    </div>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-white font-medium line-clamp-2">{video.title}</h3>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

