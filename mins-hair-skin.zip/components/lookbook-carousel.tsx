"use client"

import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { useState } from "react"

export default function LookbookCarousel() {
  const [currentSlide, setCurrentSlide] = useState(0)

  const lookbooks = [
    {
      title: "Hướng dẫn vuốt tóc layer tại nhà mà vẫn đẹp hoàn hảo",
      image: "/placeholder.svg",
    },
    {
      title: 'Bí quyết chăm sóc tóc Sport để anh em luôn "chuẩn men"',
      image: "/placeholder.svg",
    },
    {
      title: "Quiff – Đối góc với chất hoài cổ",
      image: "/placeholder.svg",
    },
  ]

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % lookbooks.length)
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + lookbooks.length) % lookbooks.length)
  }

  return (
    <section className="py-16 bg-zinc-900">
      <div className="container mx-auto">
        <h2 className="text-3xl font-bold text-white mb-8">LOOKBOOK THỜI TRANG MIN SHAIR SKIN</h2>
        <div className="relative">
          <div className="overflow-hidden">
            <div
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${currentSlide * 100}%)` }}
            >
              {lookbooks.map((item, index) => (
                <div key={index} className="w-full flex-shrink-0 px-4">
                  <Card className="bg-zinc-800">
                    <CardContent className="p-0">
                      <div className="relative aspect-video">
                        <Image
                          src={item.image || "/placeholder.svg"}
                          alt={item.title}
                          fill
                          className="object-cover rounded-t"
                        />
                      </div>
                      <div className="p-6">
                        <h3 className="text-white font-bold text-xl">{item.title}</h3>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ))}
            </div>
          </div>
          <button
            onClick={prevSlide}
            className="absolute left-0 top-1/2 -translate-y-1/2 bg-black/50 p-2 rounded-full text-white"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            onClick={nextSlide}
            className="absolute right-0 top-1/2 -translate-y-1/2 bg-black/50 p-2 rounded-full text-white"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>
      </div>
    </section>
  )
}

