import Image from "next/image"
import Link from "next/link"

const services = [
  {
    id: 1,
    title: "Hướng dẫn vuốt tóc layer tại nhà mà vẫn đẹp hoàn hảo",
    description:
      "Layer là cứu cánh cho những anh em thuộc đội trán cao, trán dô thông minh. Và muốn tạo kiểu layer tại nhà hoàn toàn",
    images: ["/placeholder.svg", "/placeholder.svg"],
    slug: "huong-dan-vuot-toc-layer",
  },
  {
    id: 2,
    title: 'Bí quyết chăm sóc tóc Sport để anh em luôn "chuẩn men"',
    description:
      "Sport là kiểu tóc ngắn, với phần mái chỉ dài từ 5 đến 6cm và được úa đổ về phía trước. Sporty là mẫu tóc",
    images: ["/placeholder.svg", "/placeholder.svg"],
    slug: "cham-soc-toc-sport",
  },
  {
    id: 3,
    title: "Quiff – Đổi gió với chất hoài cổ",
    description:
      "Ra đời từ những năm 50 của thập kỷ trước, Quiff từng là kiểu tóc được ưa chuộng bởi những tài tử đời đầu ở",
    images: ["/placeholder.svg", "/placeholder.svg"],
    slug: "quiff-doi-gio-voi-chat-hoai-co",
  },
  {
    id: 4,
    title: "Side Swept Nam: Làm thế nào để duy trì vẻ lãng tử dài lâu?",
    description:
      "Với những anh em yêu thích vẻ cá tính, bảnh bao thương mại từ các dáng mày râu phương tây, side swept sẽ là một",
    images: ["/placeholder.svg", "/placeholder.svg"],
    slug: "side-swept-nam",
  },
  {
    id: 5,
    title: "Sidepart kiểu tóc cứ để là đẹp của hàng triệu anh em nam giới.",
    description:
      "Chắc chắn rằng có lần bạn đã từng nghe ở đâu đó về kiểu tóc side part vuốt rũ, uốn xoăn, 3/7, 7/3, 4/5, 2/8, undercut,",
    images: ["/placeholder.svg", "/placeholder.svg"],
    slug: "sidepart-kieu-toc",
  },
]

export default function ServiceContent() {
  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">DỊCH VỤ</h1>

      <div className="space-y-8">
        {services.map((service) => (
          <article key={service.id} className="border-b border-gray-200 pb-8">
            <Link href={`/dich-vu/${service.slug}`} className="group">
              <div className="grid grid-cols-2 gap-4 mb-4">
                {service.images.map((image, index) => (
                  <div key={index} className="relative aspect-[4/3]">
                    <Image
                      src={image || "/placeholder.svg"}
                      alt={`${service.title} - Image ${index + 1}`}
                      fill
                      className="object-cover rounded-lg group-hover:opacity-90 transition-opacity"
                    />
                  </div>
                ))}
              </div>
              <h2 className="text-xl font-bold mb-2 group-hover:text-[#FF9900] transition-colors">{service.title}</h2>
              <p className="text-gray-600 leading-relaxed">{service.description}</p>
            </Link>
          </article>
        ))}
      </div>
    </div>
  )
}

