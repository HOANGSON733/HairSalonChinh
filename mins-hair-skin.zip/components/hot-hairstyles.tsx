import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"

export default function HotHairstyles() {
  const hairstyles = [
    { image: "/placeholder.svg", likes: "2239" },
    { image: "/placeholder.svg", likes: "1957" },
    { image: "/placeholder.svg", likes: "881" },
    { image: "/placeholder.svg", likes: "565" },
  ]

  return (
    <section className="py-16 bg-zinc-900">
      <div className="container mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold text-white">BXH TÓC HOT THÁNG NÀY</h2>
          <a href="#" className="text-[#FF9900] hover:underline">
            XEM TẤT CẢ →
          </a>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {hairstyles.map((style, index) => (
            <Card key={index} className="bg-zinc-800">
              <CardContent className="p-4">
                <div className="relative aspect-[3/4] mb-4">
                  <Image
                    src={style.image || "/placeholder.svg"}
                    alt={`Hairstyle ${index + 1}`}
                    fill
                    className="object-cover rounded"
                  />
                </div>
                <div className="flex items-center justify-end gap-2 text-white">
                  <span>{style.likes}</span>
                  <span>Like</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

