import Image from "next/image"
import Link from "next/link"

const newProducts = [
  {
    name: "Sáp Reuzel Red Pomade Phong Cách Cổ Điển",
    price: "228,000đ",
    image: "/placeholder.svg",
  },
  {
    name: "Sáp Reuzel Clay Matte Pomade Không Bóng",
    price: "273,000đ",
    image: "/placeholder.svg",
  },
  {
    name: "Sáp Reuzel Fiber Pomade Mềm Dẻo",
    price: "271,000đ",
    image: "/placeholder.svg",
  },
  {
    name: "Sáp Reuzel Blue Pomade Độ Bóng Cao",
    price: "243,000đ",
    image: "/placeholder.svg",
  },
  {
    name: "Sáp Reuzel Green Pomade Giữ Nếp Vừa",
    price: "228,000đ",
    image: "/placeholder.svg",
  },
]

const news = [
  {
    title: "Bí mật đằng sau những cánh cửa luôn chật ních người của Salon tóc nam Min Shair Skin",
    image: "/placeholder.svg",
  },
  {
    title: "Là đàn ông, đừng bỏ lỡ 3 kiểu tóc nam Hot Trend nhất 2020 này",
    image: "/placeholder.svg",
  },
  {
    title:
      'Không nằm ngoài con sốt "Tóc uốn con sâu", Đình Trọng cùng Duy Mạnh đến Min Shair Skin để bắt Trend cho bằng được',
    image: "/placeholder.svg",
  },
  {
    title: "Hướng dẫn vuốt tóc layer tại nhà mà vẫn đẹp hoàn hảo",
    image: "/placeholder.svg",
  },
  {
    title: 'Bí quyết chăm sóc tóc Sport để anh em luôn "chuẩn men"',
    image: "/placeholder.svg",
  },
]

export default function AboutSidebar() {
  return (
    <div className="space-y-8">
      <section>
        <h2 className="text-lg font-bold bg-black text-white p-2 mb-4">SẢN PHẨM MỚI</h2>
        <div className="space-y-4">
          {newProducts.map((product, index) => (
            <Link href="#" key={index} className="flex gap-4 group">
              <div className="relative w-16 h-16 flex-shrink-0">
                <Image src={product.image || "/placeholder.svg"} alt={product.name} fill className="object-cover" />
              </div>
              <div>
                <h3 className="text-sm group-hover:text-[#FF9900] transition-colors">{product.name}</h3>
                <p className="text-red-600 font-bold">{product.price}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-lg font-bold bg-black text-white p-2 mb-4">TIN TỨC MỚI</h2>
        <div className="space-y-4">
          {news.map((item, index) => (
            <Link href="#" key={index} className="flex gap-4 group">
              <div className="relative w-16 h-16 flex-shrink-0">
                <Image src={item.image || "/placeholder.svg"} alt={item.title} fill className="object-cover" />
              </div>
              <h3 className="text-sm group-hover:text-[#FF9900] transition-colors">{item.title}</h3>
            </Link>
          ))}
        </div>
      </section>
    </div>
  )
}

