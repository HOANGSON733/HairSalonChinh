"use client"

import Link from "next/link"
import { Facebook, Twitter, Linkedin, MessageCircle } from "lucide-react"

interface BlogPostContentProps {
  post: {
    title: string
    content: string
    sections: {
      title: string
      content: string
    }[]
    relatedPosts: {
      title: string
      slug: string
    }[]
  }
}

export default function BlogPostContent({ post }: BlogPostContentProps) {
  const handleShare = (platform: string) => {
    const url = window.location.href
    const text = post.title

    switch (platform) {
      case "facebook":
        window.open(`https://www.facebook.com/sharer/sharer.php?u=${url}`, "_blank")
        break
      case "twitter":
        window.open(`https://twitter.com/intent/tweet?url=${url}&text=${text}`, "_blank")
        break
      case "linkedin":
        window.open(`https://www.linkedin.com/shareArticle?mini=true&url=${url}&title=${text}`, "_blank")
        break
      case "messenger":
        window.open(`fb-messenger://share/?link=${url}`, "_blank")
        break
    }
  }

  return (
    <article className="space-y-6">
      <h1 className="text-3xl font-bold">{post.title}</h1>

      <p className="text-gray-700 leading-relaxed">{post.content}</p>

      <div className="space-y-8">
        {post.sections.map((section, index) => (
          <section key={index}>
            <h2 className="text-xl font-bold mb-4">
              {index + 1}. {section.title}
            </h2>
            <p className="text-gray-700 leading-relaxed">{section.content}</p>
          </section>
        ))}
      </div>

      <div className="border-t border-b border-gray-200 py-4 my-8">
        <div className="flex items-center gap-4">
          <span className="text-gray-600">Chia sẻ</span>
          <button
            onClick={() => handleShare("facebook")}
            className="w-8 h-8 flex items-center justify-center rounded-full bg-blue-600 text-white hover:bg-blue-700"
          >
            <Facebook className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleShare("twitter")}
            className="w-8 h-8 flex items-center justify-center rounded-full bg-sky-500 text-white hover:bg-sky-600"
          >
            <Twitter className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleShare("linkedin")}
            className="w-8 h-8 flex items-center justify-center rounded-full bg-blue-500 text-white hover:bg-blue-600"
          >
            <Linkedin className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleShare("messenger")}
            className="w-8 h-8 flex items-center justify-center rounded-full bg-blue-400 text-white hover:bg-blue-500"
          >
            <MessageCircle className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="mt-12">
        <h3 className="text-xl font-bold mb-4">BÀI VIẾT CÙNG CHỦ ĐỀ</h3>
        <ul className="space-y-4">
          {post.relatedPosts.map((relatedPost) => (
            <li key={relatedPost.slug}>
              <Link href={`/blog/${relatedPost.slug}`} className="text-gray-700 hover:text-[#FF9900] transition-colors">
                {relatedPost.title}
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </article>
  )
}

