import Image from "next/image"
import Link from "next/link"

const blogPosts = [
  {
    id: 1,
    title: "Bí mật đằng sau những cánh cửa luôn chật ních người của Salon tóc nam Min Shair Skin",
    excerpt:
      "Đó có thể là 5 cửa hàng rộng khắp toàn quốc song 5 khi người ta không biết giải cánh hàng loạt xe máy, ô tô",
    image: "/placeholder.svg",
    slug: "bi-mat-dang-sau-nhung-canh-cua",
  },
  {
    id: 2,
    title: "Là đàn ông, đừng bỏ lỡ 3 kiểu tóc nam Hot Trend nhất 2020 này",
    excerpt:
      "Không cứ đàn ông xấu, chỉ có đàn ông chưa lựa chọn đúng kiểu tóc mà thôi. Chọn được kiểu tóc phù hợp với khuôn",
    image: "/placeholder.svg",
    slug: "3-kieu-toc-nam-hot-trend",
  },
  {
    id: 3,
    title:
      'Không nằm ngoài cơn sốt "Tóc uốn con sâu," Đình Trọng cùng Duy Mạnh đến Min Shair Skin để bắt Trend cho bằng được',
    excerpt:
      "Các tóc nam không chỉ là dấu chấm làm đẹp cho bản thân mà còn thể hiện cá tính của mỗi người. Bởi vậy, các",
    image: "/placeholder.svg",
    slug: "toc-uon-con-sau",
  },
  {
    id: 4,
    title: "Hướng dẫn vuốt tóc layer tại nhà mà vẫn đẹp hoàn hảo",
    excerpt:
      "Layer là cứu cánh cho những anh em thuộc đội trán cao, trán dô thông minh. Và muốn tạo kiểu layer tại nhà hoàn toàn",
    image: "/placeholder.svg",
    slug: "huong-dan-vuot-toc-layer",
  },
  {
    id: 5,
    title: 'Bí quyết chăm sóc tóc Sport để anh em luôn "chuẩn men"',
    excerpt: "Sport là kiểu tóc ngắn, với phần mái chỉ dài từ 5 đến 6cm và được úa đổ về phía trước. Sporty là mẫu tóc",
    image: "/placeholder.svg",
    slug: "cham-soc-toc-sport",
  },
  {
    id: 6,
    title: "Quiff – Đổi gió với chất hoài cổ",
    excerpt:
      "Ra đời từ những năm 50 của thập kỷ trước, Quiff từng là kiểu tóc được ưa chuộng bởi những tài tử đời đầu ở",
    image: "/placeholder.svg",
    slug: "quiff-doi-gio-voi-chat-hoai-co",
  },
  {
    id: 7,
    title: "Side Swept Nam: Làm thế nào để duy trì vẻ lãng tử dài lâu?",
    excerpt:
      "Với những anh em yêu thích vẻ cá tính, bảnh bao thương mại từ các dáng mày râu phương tây, side swept sẽ là một",
    image: "/placeholder.svg",
    slug: "side-swept-nam",
  },
  {
    id: 8,
    title: "Sidepart kiểu tóc cứ để là đẹp của hàng triệu anh em nam giới.",
    excerpt:
      "Chắc chắn rằng có lần bạn đã từng nghe ở đâu đó về kiểu tóc side part vuốt rũ, uốn xoăn, 3/7, 7/3, 4/6, 2/8, undercut,",
    image: "/placeholder.svg",
    slug: "sidepart-kieu-toc",
  },
]

export default function BlogContent() {
  return (
    <div className="space-y-8">
      {blogPosts.map((post) => (
        <article key={post.id} className="group relative">
          <Link href={`/blog/${post.slug}`} className="flex gap-6">
            <div className="w-1/3">
              <div className="relative aspect-[4/3]">
                <Image
                  src={post.image || "/placeholder.svg"}
                  alt={post.title}
                  fill
                  className="object-cover rounded-lg group-hover:opacity-90 transition-opacity"
                />
              </div>
            </div>
            <div className="w-2/3">
              <h2 className="text-xl font-semibold mb-2 group-hover:text-[#FF9900] transition-colors">{post.title}</h2>
              <p className="text-gray-600 line-clamp-2">{post.excerpt}</p>
            </div>
          </Link>
          <div className="border-b border-dotted border-gray-300 mt-8" />
        </article>
      ))}
    </div>
  )
}

