"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ChevronDown, Menu } from "lucide-react"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import BookingModal from "./booking-modal"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

const menuItems = [
  { name: "TRANG CHỦ", href: "/" },
  { name: "GIỚI THIỆU", href: "/gioi-thieu" },
  { name: "DỊCH VỤ", href: "/dich-vu" },
  { name: "ĐẶT LỊCH", href: "#", isBooking: true },
  { name: "BLOG", href: "/blog" },
  {
    name: "STONE",
    items: [
      { name: "Tạo kiểu tóc", href: "/stone/tao-kieu-toc" },
      { name: "Chăm sóc tóc", href: "/stone/cham-soc-toc" },
      { name: "Chăm sóc da", href: "/stone/cham-soc-da" },
      { name: "Chăm sóc cơ thể", href: "/stone/cham-soc-co-the" },
      { name: "Chăm sóc râu", href: "/stone/cham-soc-rau" },
    ],
  },
  { name: "TUYỂN DỤNG", href: "/tuyen-dung" },
  { name: "LIÊN HỆ", href: "/lien-he" },
]

export default function Navbar() {
  const [isBookingOpen, setIsBookingOpen] = useState(false)

  const handleMenuClick = (item: (typeof menuItems)[0]) => {
    if (item.isBooking) {
      setIsBookingOpen(true)
    }
  }

  return (
    <nav className="bg-white py-4 border-b sticky top-0 z-50">
      <div className="container mx-auto">
        <div className="flex flex-col lg:flex-row items-center justify-between">
          {/* Logo */}
          <div className="flex items-center justify-between w-full lg:w-auto px-4 lg:px-0">
            <Link href="/" className="block w-48">
              <Image src="/placeholder.svg" alt="Min's Hair & Skin" width={192} height={80} className="w-full" />
            </Link>

            {/* Mobile Menu Button */}
            <Sheet>
              <SheetTrigger className="lg:hidden">
                <Menu className="h-6 w-6" />
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px] sm:w-[400px]">
                <div className="flex flex-col gap-4 mt-8">
                  {menuItems.map((item) => (
                    <div key={item.name}>
                      {item.items ? (
                        <DropdownMenu>
                          <DropdownMenuTrigger className="text-lg font-medium text-gray-700 hover:text-[#FF9900] transition-colors flex items-center justify-between w-full">
                            {item.name}
                            <ChevronDown className="h-4 w-4" />
                          </DropdownMenuTrigger>
                          <DropdownMenuContent>
                            {item.items.map((subItem) => (
                              <DropdownMenuItem key={subItem.name} asChild>
                                <Link href={subItem.href}>{subItem.name}</Link>
                              </DropdownMenuItem>
                            ))}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      ) : (
                        <button
                          onClick={() => handleMenuClick(item)}
                          className="text-lg font-medium text-gray-700 hover:text-[#FF9900] transition-colors w-full text-left"
                        >
                          {item.name}
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </SheetContent>
            </Sheet>
          </div>

          {/* Desktop Menu */}
          <div className="hidden lg:flex space-x-8">
            {menuItems.map((item) => {
              if (item.items) {
                return (
                  <DropdownMenu key={item.name}>
                    <DropdownMenuTrigger className="text-gray-700 hover:text-[#FF9900] transition-colors font-medium flex items-center gap-1">
                      {item.name}
                      <ChevronDown className="w-4 h-4" />
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                      {item.items.map((subItem) => (
                        <DropdownMenuItem key={subItem.name} asChild>
                          <Link href={subItem.href}>{subItem.name}</Link>
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuContent>
                  </DropdownMenu>
                )
              }

              if (item.isBooking) {
                return (
                  <button
                    key={item.name}
                    onClick={() => handleMenuClick(item)}
                    className="text-gray-700 hover:text-[#FF9900] transition-colors font-medium"
                  >
                    {item.name}
                  </button>
                )
              }

              return (
                <Link
                  key={item.name}
                  href={item.href}
                  className="text-gray-700 hover:text-[#FF9900] transition-colors font-medium"
                >
                  {item.name}
                </Link>
              )
            })}
          </div>
        </div>
      </div>

      <BookingModal open={isBookingOpen} onOpenChange={setIsBookingOpen} />
    </nav>
  )
}

