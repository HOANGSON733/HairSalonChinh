"use client"

import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import Image from "next/image"
import { Crown } from "lucide-react"

const services = [
  {
    category: "uon",
    items: [
      {
        title: "Uốn Phông Tiêu Chuẩn",
        description: "TẠO KIỂU DỄ DÁNG VÀO NẾP NHANH CHÓNG",
        price: "260K",
        memberPrice: "234K",
        image: "/placeholder.svg",
      },
      {
        title: "Tạo Phông",
        description: "HIỆU QUẢ TRONG 15 NGÀY THAY ĐỔI KIỂU TÓC LINH HOẠT",
        price: "99K",
        image: "/placeholder.svg",
      },
      {
        title: "Uốn Cao Cấp",
        description: "BỔ SUNG COLLAGEN KERATIN SINH HỌC KHÔNG AMONIAC TÓC PHỒNG HÓA HẢO",
        price: "349K",
        memberPrice: "315K",
        image: "/placeholder.svg",
      },
      {
        title: "Premlock",
        description: "HOT TREND 2020 CĂN BẢN XU HƯỚNG VỚI KIỂU TÓC NHÀ VÔ ĐỊCH",
        price: "899K",
        memberPrice: "799K",
        image: "/placeholder.svg",
      },
    ],
  },
]

export default function ServicePackages() {
  const packages = [
    {
      name: "SHINE COMBO V2",
      price: "150.000đ",
      features: ["Cắt tóc nam", "Massage đầu", "Gội đầu"],
    },
    {
      name: "SHINE COMBO ++",
      price: "250.000đ",
      features: ["Cắt tóc nam", "Massage đầu", "Gội đầu", "Uốn tóc"],
    },
    {
      name: "SHINE PREMIUM",
      price: "350.000đ",
      features: ["Cắt tóc nam", "Massage đầu", "Gội đầu", "Uốn tóc", "Nhuộm tóc"],
    },
  ]

  return (
    <section className="py-16 bg-zinc-900">
      <div className="container mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold text-white">DỊCH VỤ TẠI MIN SHAIR SKIN</h2>
          <a href="#" className="text-[#FF9900] hover:underline">
            XEM TẤT CẢ →
          </a>
        </div>

        <Tabs defaultValue="uon" className="w-full">
          <TabsList className="w-full justify-start mb-8 bg-transparent border-b border-zinc-800 h-auto flex-wrap">
            <TabsTrigger
              value="combo"
              className="data-[state=active]:bg-transparent data-[state=active]:text-white text-zinc-400 gap-2 px-6 py-4"
            >
              <Image src="/placeholder.svg" alt="" width={20} height={20} />
              Combo
            </TabsTrigger>
            <TabsTrigger
              value="uon"
              className="data-[state=active]:bg-[#FFD700] data-[state=active]:text-black text-zinc-400 gap-2 px-6 py-4"
            >
              <Image src="/placeholder.svg" alt="" width={20} height={20} />
              Uốn
            </TabsTrigger>
            <TabsTrigger
              value="nhuom"
              className="data-[state=active]:bg-transparent data-[state=active]:text-white text-zinc-400 gap-2 px-6 py-4"
            >
              <Image src="/placeholder.svg" alt="" width={20} height={20} />
              Nhuộm
            </TabsTrigger>
            <TabsTrigger
              value="duong"
              className="data-[state=active]:bg-transparent data-[state=active]:text-white text-zinc-400 gap-2 px-6 py-4"
            >
              <Image src="/placeholder.svg" alt="" width={20} height={20} />
              Dưỡng
            </TabsTrigger>
            <TabsTrigger
              value="chamsoc"
              className="data-[state=active]:bg-transparent data-[state=active]:text-white text-zinc-400 gap-2 px-6 py-4"
            >
              <Image src="/placeholder.svg" alt="" width={20} height={20} />
              Chăm sóc da
            </TabsTrigger>
            <TabsTrigger
              value="khac"
              className="data-[state=active]:bg-transparent data-[state=active]:text-white text-zinc-400 gap-2 px-6 py-4"
            >
              <Image src="/placeholder.svg" alt="" width={20} height={20} />
              Khác
            </TabsTrigger>
          </TabsList>

          <TabsContent value="uon" className="mt-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {services[0].items.map((service, index) => (
                <Card key={index} className="bg-zinc-800 border-0 overflow-hidden">
                  <CardContent className="p-0">
                    <div className="relative aspect-[4/3]">
                      <Image
                        src={service.image || "/placeholder.svg"}
                        alt={service.title}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="p-4">
                      <h3 className="text-white font-bold mb-2">{service.title}</h3>
                      <p className="text-sm text-gray-400 mb-4">{service.description}</p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-2xl font-bold text-[#FF9900]">{service.price}</span>
                          {service.memberPrice && (
                            <div className="bg-zinc-900 px-2 py-1 rounded flex items-center gap-1">
                              <Crown className="w-4 h-4 text-[#FFD700]" />
                              <span className="text-sm text-white">SILVER MEMBER</span>
                              <span className="text-[#FF9900] font-bold">{service.memberPrice}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Add other TabsContent components for other service categories */}
        </Tabs>
      </div>
    </section>
  )
}

