import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"

export default function CelebrityVisits() {
  const celebrities = [
    {
      name: "Chim Sẻ Đi Nắng",
      description: "Huyền Thoại Game Đế Chế Việt Nam",
      image: "/placeholder.svg",
    },
    {
      name: "1977 Vlog",
      description: "Kênh Youtube Triệu View",
      image: "/placeholder.svg",
    },
    {
      name: "Độ Duy Nam",
      description: "Ngôi Sao Nhạc Chế Triệu View",
      image: "/placeholder.svg",
    },
    {
      name: "Nguyễn Tiến Linh",
      description: "Tuyển Thủ ĐTQG Việt Nam",
      image: "/placeholder.svg",
    },
  ]

  return (
    <section className="py-16 bg-black">
      <div className="container mx-auto">
        <h2 className="text-3xl font-bold text-white mb-8">CÙNG SAO VIỆT ĐẾN MIN SHAIR SKIN TỎA SÁNG</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {celebrities.map((celeb) => (
            <Card key={celeb.name} className="bg-zinc-800">
              <CardContent className="p-4">
                <div className="relative aspect-square mb-4">
                  <Image
                    src={celeb.image || "/placeholder.svg"}
                    alt={celeb.name}
                    fill
                    className="object-cover rounded"
                  />
                </div>
                <h3 className="text-white font-bold mb-2">{celeb.name}</h3>
                <p className="text-gray-400 text-sm">{celeb.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

