import Image from "next/image"
import { Phone } from "lucide-react"

export default function MainFooter() {
  return (
    <footer className="bg-black text-white py-16">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <div>
            <h3 className="text-xl font-bold mb-4">CÔNG TY CỔ PHẦN TMDV MIN SHARK SKIN</h3>
            <div className="space-y-2 text-gray-400">
              <p>82 Trần Đại Nghĩa, P. Đồng Tâm, Q. Hai Bà Trưng</p>
              <p>Số giấy chứng nhận kinh doanh: 010.7487.993</p>
              <p>Ngày cấp: 08/06/2016</p>
              <p>Nơi cấp: Sở kế hoạch và đầu tư TP Hà Nội</p>
              <p className="text-white font-bold mt-4">Giờ phục vụ 8:30 – 21:30 (kể cả thứ 7, CN)</p>
              <div className="flex items-center gap-2 text-[#FF9900] font-bold">
                <Phone className="w-6 h-6" />
                <span>0961.665.266</span>
              </div>
            </div>
          </div>
          <div className="flex flex-col items-end justify-between">
            <div className="flex gap-4">
              <Image src="/placeholder.svg" alt="Verified" width={100} height={40} className="object-contain" />
              <Image src="/placeholder.svg" alt="DMCA" width={100} height={40} className="object-contain" />
            </div>
            <div className="flex gap-4">
              <Image src="/placeholder.svg" alt="Visa" width={60} height={40} className="object-contain" />
              <Image src="/placeholder.svg" alt="Mastercard" width={60} height={40} className="object-contain" />
            </div>
            <p className="text-gray-400 text-sm">Copyright 2015 Min Shair Skin, Inc. All Rights Reserved</p>
          </div>
        </div>
      </div>
    </footer>
  )
}

