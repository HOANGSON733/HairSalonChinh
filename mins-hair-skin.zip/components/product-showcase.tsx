"use client"

import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { useRef } from "react"

export default function ProductShowcase() {
  const sliderRef = useRef<HTMLDivElement>(null)

  const products = [
    {
      name: "Sáp Reuzel Clay Matte Pomade Không Bóng",
      price: "273,000đ",
      image: "/placeholder.svg",
    },
    {
      name: "Sáp Reuzel Fiber Pomade Mềm Dẻo",
      price: "271,000đ",
      image: "/placeholder.svg",
    },
    {
      name: "Sáp Reuzel Green Pomade Giữ Nếp Vừa",
      price: "228,000đ",
      image: "/placeholder.svg",
    },
    {
      name: "Sáp Reuzel Blue Pomade Độ Bóng Cao",
      price: "243,000đ",
      image: "/placeholder.svg",
    },
  ]

  const scroll = (direction: "left" | "right") => {
    if (sliderRef.current) {
      const scrollAmount = direction === "left" ? -300 : 300
      sliderRef.current.scrollBy({ left: scrollAmount, behavior: "smooth" })
    }
  }

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-2xl font-bold text-black">MIN SHAIR SKIN STORE - SỐ 1 VỀ MỸ PHẨM NAM</h2>
          <a href="#" className="text-[#FF9900] hover:underline font-medium">
            XEM TẤT CẢ →
          </a>
        </div>
        <div className="relative">
          <button
            onClick={() => scroll("left")}
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 z-10 w-8 h-8 bg-white shadow-lg rounded-full flex items-center justify-center hover:bg-gray-100"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={() => scroll("right")}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 z-10 w-8 h-8 bg-white shadow-lg rounded-full flex items-center justify-center hover:bg-gray-100"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
          <div
            ref={sliderRef}
            className="flex gap-6 overflow-x-auto scrollbar-hide snap-x snap-mandatory px-4"
            style={{
              scrollbarWidth: "none",
              msOverflowStyle: "none",
              WebkitOverflowScrolling: "touch",
            }}
          >
            {products.map((product, index) => (
              <Card
                key={index}
                className="bg-white border-0 flex-shrink-0 w-[280px] snap-start hover:shadow-lg transition-shadow duration-300"
              >
                <CardContent className="p-4">
                  <div className="aspect-square relative mb-4 flex items-center justify-center">
                    <Image
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      width={200}
                      height={200}
                      className="object-contain"
                    />
                  </div>
                  <h3 className="font-medium text-center text-gray-800 mb-3 h-12 line-clamp-2">{product.name}</h3>
                  <div className="flex justify-center">
                    <span className="bg-[#FFD700] text-black px-4 py-1 rounded-full font-bold">{product.price}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

