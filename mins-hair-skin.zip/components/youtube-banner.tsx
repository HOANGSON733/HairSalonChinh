import { Youtube } from "lucide-react"

export default function YoutubeBanner() {
  return (
    <div className="bg-[#FF0000] text-white py-3">
      <div className="container mx-auto flex items-center justify-center gap-4">
        <Youtube className="w-8 h-8" />
        <div className="font-bold">SUBSCRIBE</div>
        <div className="text-sm">ĐỂ ĐẸP TRAI HƠN MỖI NGÀY</div>
      </div>
    </div>
  )
}

