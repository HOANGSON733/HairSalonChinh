import { Phone } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function StoreLocations() {
  const locations = [
    {
      id: 3,
      address: "54 Nguyễn Huy Tưởng",
      district: "P. TX Trung, Q. Thanh Xuân",
      phone: "0896.565.265",
    },
    {
      id: 4,
      address: "31 Trần Phú P. Văn",
      district: "Quận 5, Hà Đông",
      phone: "0896.565.164",
    },
    {
      id: 5,
      address: "407 Trường Chinh P.",
      district: "Phương Trung, Q. Thanh Xuân",
      phone: "0896.565.156",
    },
  ]

  return (
    <section className="py-16 bg-zinc-900">
      <div className="container mx-auto">
        <h2 className="text-3xl font-bold text-white mb-4">DANH SÁCH CỬA HÀNG (8H30 - 21H30)</h2>
        <div className="bg-[#FFD700] text-black p-4 mb-6 rounded">TP. Hà Nội (18 Salon)</div>
        <div className="space-y-4">
          {locations.map((location) => (
            <div key={location.id} className="bg-zinc-800 p-4 rounded-lg flex items-center justify-between">
              <div>
                <div className="text-white font-bold">{location.address}</div>
                <div className="text-gray-400 text-sm">{location.district}</div>
                <div className="text-[#FF9900]">{location.phone}</div>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <Phone className="w-4 h-4 mr-2" />
                  Gọi ngay
                </Button>
                <Button variant="default" size="sm">
                  Đặt lịch
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

