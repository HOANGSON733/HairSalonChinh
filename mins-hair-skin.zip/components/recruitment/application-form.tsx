"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function ApplicationForm() {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    position: "",
    location: "",
    experience: "",
    message: "",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission
    console.log("Form submitted:", formData)
  }

  return (
    <section className="max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold mb-6">ỨNG TUYỂN NGAY</h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Input
            placeholder="Họ và tên *"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            required
          />
          <Input
            placeholder="Số điện thoại *"
            type="tel"
            value={formData.phone}
            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            required
          />
          <Input
            placeholder="Email"
            type="email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
          />
          <Select value={formData.position} onValueChange={(value) => setFormData({ ...formData, position: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Vị trí ứng tuyển *" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="stylist">Nhân Viên Tạo Mẫu Tóc Nam</SelectItem>
              <SelectItem value="washer">Nhân Viên Gội Đầu</SelectItem>
              <SelectItem value="manager">Quản Lý Cửa Hàng</SelectItem>
            </SelectContent>
          </Select>
          <Select value={formData.location} onValueChange={(value) => setFormData({ ...formData, location: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Địa điểm làm việc *" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="hanoi">Hà Nội</SelectItem>
              <SelectItem value="hcm">Hồ Chí Minh</SelectItem>
            </SelectContent>
          </Select>
          <Input
            placeholder="Kinh nghiệm làm việc"
            value={formData.experience}
            onChange={(e) => setFormData({ ...formData, experience: e.target.value })}
          />
        </div>
        <Textarea
          placeholder="Giới thiệu bản thân"
          value={formData.message}
          onChange={(e) => setFormData({ ...formData, message: e.target.value })}
          className="min-h-[120px]"
        />
        <div className="flex justify-center">
          <Button type="submit" className="bg-[#FF9900] hover:bg-[#FF8800] text-white px-8">
            GỬI ĐƠN ỨNG TUYỂN
          </Button>
        </div>
      </form>
    </section>
  )
}

