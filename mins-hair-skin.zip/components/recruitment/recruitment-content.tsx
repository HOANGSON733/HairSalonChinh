import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { BadgeCheck } from "lucide-react"

const positions = [
  {
    title: "Nhân Viên Tạo Mẫu Tóc Nam",
    requirements: [
      "Nam/Nữ từ 18-35 tuổi",
      "Có kinh nghiệm cắt tóc nam tối thiểu 1 năm",
      "Có tinh thần học hỏi, cầu tiến",
      "Có kỹ năng giao tiếp tốt",
    ],
    benefits: [
      "Thu nhập từ 8-20 triệu/tháng",
      "Được đào tạo chuyên sâu",
      "Môi trường làm việc chuyên nghiệp",
      "Cơ hội thăng tiến rõ ràng",
    ],
    locations: ["Hà Nội", "Hồ Chí Minh"],
  },
  {
    title: "Nhân Viên Gội Đầu",
    requirements: ["Nam/Nữ từ 18-35 tuổi", "Không yêu cầu kinh nghiệm", "Ngoại hình ưa nhìn", "Thái độ phục vụ tốt"],
    benefits: [
      "Thu nhập từ 5-10 triệu/tháng",
      "Được đào tạo kỹ năng",
      "Phụ cấp, thưởng theo doanh số",
      "Bảo hiểm đầy đủ",
    ],
    locations: ["Hà Nội"],
  },
  {
    title: "Quản Lý Cửa Hàng",
    requirements: [
      "Nam/Nữ từ 25-40 tuổi",
      "Kinh nghiệm quản lý tối thiểu 2 năm",
      "Kỹ năng lãnh đạo tốt",
      "Có khả năng đào tạo nhân viên",
    ],
    benefits: [
      "Thu nhập từ 15-25 triệu/tháng",
      "Thưởng theo KPI",
      "Chế độ phúc lợi hấp dẫn",
      "Cơ hội phát triển sự nghiệp",
    ],
    locations: ["Hà Nội", "Hồ Chí Minh"],
  },
]

const culture = [
  {
    title: "Môi Trường Chuyên Nghiệp",
    description: "Làm việc trong không gian hiện đại, quy trình chuẩn quốc tế",
    image: "/placeholder.svg",
  },
  {
    title: "Đào Tạo Liên Tục",
    description: "Cập nhật xu hướng mới nhất, nâng cao tay nghề thường xuyên",
    image: "/placeholder.svg",
  },
  {
    title: "Cơ Hội Thăng Tiến",
    description: "Lộ trình thăng tiến rõ ràng, đãi ngộ theo năng lực",
    image: "/placeholder.svg",
  },
]

export default function RecruitmentContent() {
  return (
    <div className="space-y-12">
      <section>
        <h1 className="text-3xl font-bold mb-8">TUYỂN DỤNG</h1>
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {positions.map((position) => (
            <Card key={position.title} className="bg-white">
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-4">{position.title}</h3>

                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Yêu cầu:</h4>
                    <ul className="space-y-2">
                      {position.requirements.map((req) => (
                        <li key={req} className="flex items-start gap-2 text-gray-600">
                          <BadgeCheck className="w-5 h-5 text-[#FF9900] flex-shrink-0 mt-0.5" />
                          <span>{req}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Quyền lợi:</h4>
                    <ul className="space-y-2">
                      {position.benefits.map((benefit) => (
                        <li key={benefit} className="flex items-start gap-2 text-gray-600">
                          <BadgeCheck className="w-5 h-5 text-[#FF9900] flex-shrink-0 mt-0.5" />
                          <span>{benefit}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Địa điểm:</h4>
                    <p className="text-gray-600">{position.locations.join(", ")}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="bg-zinc-900 text-white py-12 -mx-4 px-4 sm:-mx-6 sm:px-6 lg:-mx-8 lg:px-8">
        <div className="container mx-auto">
          <h2 className="text-2xl font-bold mb-8">VĂN HÓA MIN SHAIR SKIN</h2>
          <div className="grid gap-8 md:grid-cols-3">
            {culture.map((item) => (
              <div key={item.title} className="text-center">
                <div className="relative w-32 h-32 mx-auto mb-4">
                  <Image
                    src={item.image || "/placeholder.svg"}
                    alt={item.title}
                    fill
                    className="object-cover rounded-full"
                  />
                </div>
                <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                <p className="text-gray-400">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}

