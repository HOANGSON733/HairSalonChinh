import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"

export default function BlogSection() {
  const posts = [
    {
      title: "BÍ KÍP SÁNG DA NHANH CHÓNG CÁNH CỬA LUÔN CHẤT",
      excerpt: "Các tips về chăm sóc da nam giới...",
      image: "/placeholder.svg",
    },
    {
      title: "LÀ ĐÀN ÔNG, KHÔNG ĐỂ Ý ĐẾN TÓC NAM HỜI TRÔNG NHẤT 2020 NÀY",
      excerpt: "Xu hướng tóc nam hot nhất...",
      image: "/placeholder.svg",
    },
  ]

  return (
    <section className="py-16 bg-zinc-900">
      <div className="container mx-auto">
        <h2 className="text-3xl font-bold text-white mb-8">BÍ QUYẾT ĐẸP TRAI TỪ MIN SHARK SKIN</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {posts.map((post) => (
            <Card key={post.title} className="bg-zinc-800 text-white">
              <CardContent className="p-0">
                <div className="aspect-video relative">
                  <Image src={post.image || "/placeholder.svg"} alt={post.title} fill className="object-cover" />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">{post.title}</h3>
                  <p className="text-gray-400">{post.excerpt}</p>
                  <button className="text-[#FF9900] mt-4 hover:underline">Xem thêm →</button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

