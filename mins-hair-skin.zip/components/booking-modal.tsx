"use client"

import { useState } from "react"
import { X } from "lucide-react"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface BookingModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export default function BookingModal({ open, onOpenChange }: BookingModalProps) {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    service: "",
    staff: "",
    date: "",
    time: "",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission
    console.log("Form submitted:", formData)
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-black text-white border-yellow-500 p-0 overflow-hidden">
        <div className="p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold">ĐẶT LỊCH GIỮ CHỖ</h2>
            <button onClick={() => onOpenChange(false)} className="text-white hover:text-gray-300 transition-colors">
              <X className="h-6 w-6" />
            </button>
          </div>

          <p className="text-gray-300 mb-6 text-center">
            Quý khách vui lòng nhập đủ thông tin, chúng tôi sẽ gọi lại ngay khi nhận được email
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                placeholder="Họ và tên"
                className="bg-transparent border-white/20 text-white placeholder:text-gray-400"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />

              <Input
                placeholder="Số điện thoại"
                type="tel"
                className="bg-transparent border-white/20 text-white placeholder:text-gray-400"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                required
              />

              <Select value={formData.service} onValueChange={(value) => setFormData({ ...formData, service: value })}>
                <SelectTrigger className="bg-transparent border-white/20 text-white">
                  <SelectValue placeholder="Chọn dịch vụ" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cat-toc">Cắt tóc</SelectItem>
                  <SelectItem value="uon">Uốn</SelectItem>
                  <SelectItem value="nhuom">Nhuộm</SelectItem>
                </SelectContent>
              </Select>

              <Select value={formData.staff} onValueChange={(value) => setFormData({ ...formData, staff: value })}>
                <SelectTrigger className="bg-transparent border-white/20 text-white">
                  <SelectValue placeholder="Chọn nhân viên" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="staff-1">Nhân viên 1</SelectItem>
                  <SelectItem value="staff-2">Nhân viên 2</SelectItem>
                  <SelectItem value="staff-3">Nhân viên 3</SelectItem>
                </SelectContent>
              </Select>

              <Input
                type="date"
                className="bg-transparent border-white/20 text-white"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                required
              />

              <Input
                type="time"
                className="bg-transparent border-white/20 text-white"
                value={formData.time}
                onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                required
              />
            </div>

            <div className="flex justify-center mt-6">
              <Button
                type="submit"
                className="bg-yellow-500 hover:bg-yellow-600 text-black font-bold px-8 py-2 rounded-full"
              >
                GỬI ĐI
              </Button>
            </div>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  )
}

